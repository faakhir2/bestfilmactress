import React from "react";

const TailwindCss = () => {
  return <div className="pb-7 gap-14 lg:gap-10">TailwindCss?</div>;
};

export default TailwindCss;
